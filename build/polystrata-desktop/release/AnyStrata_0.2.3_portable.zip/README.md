Portable AnyStrata.

1. Double-click AnyStrata.exe (or run AnyStrata.bat).
2. Choose a model on first launch; the engine downloads from this release folder.
